import Link from "next/link";
import Image from "next/image";
export default function Hero(){
  return (<section className="relative bg-beige overflow-hidden">
    <div className="container-x grid md:grid-cols-2 min-h-[560px] items-center pt-6">
      <div className="relative z-10 py-16">
        <div className="bg-white/70 backdrop-blur p-8 max-w-sm">
          <p className="text-[10px] tracking-[0.3em] text-neutral-500">MONA FASHION</p>
          <h1 className="text-2xl md:text-3xl font-light mt-2 leading-snug">Bộ sưu tập &quot;Mùa xuân&quot;</h1>
          <Link href="/shop" className="inline-block mt-6 bg-white px-6 py-3 text-[11px] tracking-[0.2em] hover:bg-black hover:text-white transition">ĐẾN CỬA HÀNG</Link>
        </div>
      </div>
      <div className="relative h-[420px] md:h-[560px]">
        <Image src="/images/site/hero.jpg" alt="Mona Fashion Spring Collection" fill className="object-cover object-top" priority />
      </div>
    </div>
    <div className="absolute bottom-0 right-0 bg-white/80 flex"><button className="px-4 py-3">‹</button><button className="px-4 py-3">›</button></div>
  </section>);
}
