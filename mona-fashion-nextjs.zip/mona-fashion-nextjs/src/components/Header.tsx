"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/context/AuthContext";
const nav = [{label:"TRANG CHỦ",href:"/"},{label:"SHOP",href:"/shop"},{label:"VỀ CHÚNG TÔI",href:"/about"},{label:"MONA",href:"/",logo:true},{label:"COMING SOON",href:"/coming-soon"},{label:"TIN TỨC",href:"/blog"},{label:"LIÊN HỆ",href:"/contact"}];
/* Icon vẽ nét (outline) giống hệt bản gốc: kính lúp tìm kiếm, người dùng, túi mua hàng */
const SearchIcon = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" className="w-[22px] h-[22px]"><circle cx="11" cy="11" r="7" /><path d="M16.3 16.3 L21 21" /></svg>);
const UserIcon = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" className="w-[23px] h-[23px]"><circle cx="12" cy="8" r="3.8" /><path d="M4.9 20.1c1-3.7 3.7-5.6 7.1-5.6s6.1 1.9 7.1 5.6" /></svg>);
const BagIcon = () => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" className="w-[23px] h-[23px]"><path d="M4.6 9h14.8l-1 11a2 2 0 0 1-2 1.8H7.6a2 2 0 0 1-2-1.8L4.6 9Z" /><path d="M9 9V7.2a3 3 0 0 1 6 0V9" /></svg>);
export default function Header(){
  const pathname = usePathname();
  const {count,setOpen}=useCart();
  const {user}=useAuth();
  return (<header className={`relative z-40 ${pathname === "/contact" ? "bg-[#e4e9ec]" : "bg-beige"}`}>
    <div className="container-x flex items-center justify-between py-5 text-[#2e2a24]">
      <button aria-label="Tìm kiếm" className="cursor-pointer"><SearchIcon /></button>
      <nav className="hidden md:flex items-center gap-8 text-[11px] tracking-[0.18em] font-medium font-heading">
        {nav.map((n,i)=> n.logo ? <Link key={i} href="/" className="text-center leading-none mx-2"><span className="text-2xl tracking-[0.35em] font-light">MONA</span><span className="block text-[8px] tracking-[0.5em] mt-1">FASHION</span></Link> : <Link key={i} href={n.href} className="hover:underline underline-offset-4">{n.label}</Link>)}
      </nav>
      <Link href="/" className="md:hidden text-xl tracking-[0.3em]">MONA</Link>
      <div className="flex items-center gap-4">
        <Link href="/account" aria-label="Tài khoản của tôi" className="cursor-pointer flex items-center" title={user ? user.name : "Đăng nhập / Đăng ký"}><UserIcon />{user && <span className="hidden md:inline text-xs ml-1 max-w-[90px] truncate align-middle">{user.name}</span>}</Link>
        <button onClick={()=>setOpen(true)} aria-label="Giỏ hàng" className="relative cursor-pointer"><BagIcon /><span className="absolute -top-2 -right-2.5 bg-[#4d4d4d] text-white text-[10px] min-w-[18px] h-[18px] px-0.5 rounded-full grid place-items-center leading-none">{count}</span></button>
      </div>
    </div>
    <nav className="md:hidden flex justify-center gap-4 text-[10px] tracking-widest text-[#2e2a24] pb-3 font-heading">{nav.filter(n=>!n.logo).map((n,i)=><Link key={i} href={n.href}>{n.label}</Link>)}</nav>
  </header>);
}
