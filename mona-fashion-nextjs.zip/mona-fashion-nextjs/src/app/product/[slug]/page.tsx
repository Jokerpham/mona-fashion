"use client";
import { useState } from "react";
import { notFound } from "next/navigation";
import Image from "next/image";
import { products } from "@/data/products";
import { formatPrice } from "@/lib/format";
import { useCart } from "@/context/CartContext";
import ProductCard from "@/components/ProductCard";
export default function ProductPage({ params }: { params: { slug: string } }){
  const product = products.find(p=>p.slug===params.slug);
  const [size,setSize]=useState(product?.sizes[0]||"Free");
  const {add}=useCart();
  if(!product) return notFound();
  const related = products.filter(p=>p.id!==product.id).slice(0,4);
  return (<div className="container-x pt-12 pb-20">
    <div className="grid md:grid-cols-2 gap-10">
      <div className="relative aspect-[4/5] bg-neutral-100"><Image src={product.image} alt={product.name} fill className="object-cover" /></div>
      <div><p className="text-xs tracking-[0.3em] text-neutral-400 uppercase">{product.category}</p>
        <h1 className="text-3xl font-light mt-3">{product.name}</h1>
        <p className="text-xl font-semibold mt-4">{formatPrice(product.price)} {product.oldPrice && <span className="line-through text-neutral-400 text-base font-normal ml-2">{formatPrice(product.oldPrice)}</span>}</p>
        <p className="text-neutral-600 leading-relaxed mt-5">{product.description}</p>
        <p className="font-medium mt-8 mb-3 text-sm">Chọn size</p>
        <div className="flex gap-2">{product.sizes.map(s=><button key={s} onClick={()=>setSize(s)} className={size===s?"bg-black text-white border px-4 py-2":"border px-4 py-2"}>{s}</button>)}</div>
        <button onClick={()=>add(product,size)} className="bg-black text-white w-full py-4 mt-8 tracking-[0.2em] text-sm">THÊM VÀO GIỎ HÀNG</button>
        <ul className="text-sm text-neutral-500 space-y-2 mt-6"><li>✓ Miễn phí vận chuyển đơn từ 500.000đ</li><li>✓ Đổi trả trong 30 ngày</li><li>✓ Thanh toán COD / chuyển khoản</li></ul>
      </div>
    </div>
    <h2 className="text-xl tracking-widest mt-20 mb-8 text-center">SẢN PHẨM LIÊN QUAN</h2>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">{related.map(p=><ProductCard key={p.id} product={p} />)}</div>
  </div>);
}
