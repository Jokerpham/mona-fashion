"use client";
import { useState } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";

const inputCls =
  "w-full bg-transparent border-b border-neutral-300 focus:border-black outline-none py-3 placeholder:text-neutral-500";
const labelCls = "block text-[15px] text-neutral-500 mb-1";

export default function AccountPage() {
  const { user, login, register, logout } = useAuth();
  const [tab, setTab] = useState<"login" | "register">("login");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  // login form
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);

  // register form
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");

  if (user) {
    return (
      <div className="container-x py-14 max-w-3xl">
        <h1 className="text-4xl font-light">My Account</h1>
        <div className="mt-10 border p-8">
          <p className="text-lg">
            Xin chào, <span className="font-medium">{user.name}</span>
          </p>
          <p className="text-neutral-500 mt-2">{user.email}</p>
          <div className="grid sm:grid-cols-3 gap-4 mt-8 text-center text-sm">
            <Link href="/shop" className="border py-5 hover:bg-neutral-50">Đơn hàng của tôi</Link>
            <Link href="/checkout" className="border py-5 hover:bg-neutral-50">Thanh toán</Link>
            <Link href="/contact" className="border py-5 hover:bg-neutral-50">Hỗ trợ / Liên hệ</Link>
          </div>
          <button
            onClick={logout}
            className="mt-8 bg-[#171a21] text-white px-8 py-3.5 text-sm tracking-[0.2em]"
          >
            ĐĂNG XUẤT
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative bg-white">
      <div className="container-x py-10">
        <div className="flex items-start justify-between">
          <h1 className="text-4xl font-light">My Account</h1>
          <Link href="/" aria-label="Đóng" className="text-3xl leading-none text-neutral-700 hover:text-black">
            ×
          </Link>
        </div>

        {/* Tabs như ảnh mẫu */}
        <div className="flex justify-center gap-16 mt-6">
          <button
            onClick={() => { setTab("login"); setError(""); setNotice(""); }}
            className={
              tab === "login"
                ? "text-2xl font-medium border-b-2 border-black pb-1"
                : "text-2xl text-neutral-400 pb-1 hover:text-black"
            }
          >
            Đăng nhập
          </button>
          <button
            onClick={() => { setTab("register"); setError(""); setNotice(""); }}
            className={
              tab === "register"
                ? "text-2xl font-medium border-b-2 border-black pb-1"
                : "text-2xl text-neutral-400 pb-1 hover:text-black"
            }
          >
            Đăng ký
          </button>
        </div>

        <div className="max-w-[500px] mx-auto mt-14 pb-16">
          {error && (
            <p className="bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 mb-6">{error}</p>
          )}
          {notice && (
            <p className="bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm px-4 py-3 mb-6">{notice}</p>
          )}

          {tab === "login" ? (
            <form
              className="space-y-9"
              onSubmit={(e) => {
                e.preventDefault();
                const r = login(identifier.trim(), password, remember);
                if (!r.ok) setError(r.error || "Đăng nhập thất bại");
              }}
            >
              <div>
                <label htmlFor="login-id" className={labelCls}>
                  Tên tài khoản hoặc địa chỉ email <span className="text-red-500">*</span>
                </label>
                <input id="login-id" required value={identifier} onChange={(e) => setIdentifier(e.target.value)} className={inputCls} />
              </div>
              <div>
                <label htmlFor="login-pass" className={labelCls}>
                  Mật khẩu <span className="text-red-500">*</span>
                </label>
                <input id="login-pass" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className={inputCls} />
              </div>
              <label className="flex items-center gap-3 text-neutral-500 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                  className="w-6 h-6 accent-neutral-300"
                />
                Ghi nhớ mật khẩu
              </label>
              <button type="submit" className="w-full bg-[#171a21] text-white py-6 text-sm tracking-[0.2em] hover:bg-black transition">
                ĐĂNG NHẬP
              </button>
              <p className="text-center pt-2">
                <Link href="/forgot-password" className="text-sm tracking-widest underline underline-offset-8">
                  QUÊN MẬT KHẨU?
                </Link>
              </p>
            </form>
          ) : (
            <form
              className="space-y-9"
              onSubmit={(e) => {
                e.preventDefault();
                if (regPassword.length < 6) {
                  setError("Mật khẩu cần tối thiểu 6 ký tự.");
                  return;
                }
                const r = register(name.trim(), email.trim(), regPassword);
                if (!r.ok) setError(r.error || "Đăng ký thất bại");
                else setNotice("Tạo tài khoản thành công. Chào mừng bạn đến MONA Fashion!");
              }}
            >
              <div>
                <label htmlFor="reg-name" className={labelCls}>
                  Tên tài khoản <span className="text-red-500">*</span>
                </label>
                <input id="reg-name" required value={name} onChange={(e) => setName(e.target.value)} className={inputCls} />
              </div>
              <div>
                <label htmlFor="reg-email" className={labelCls}>
                  Địa chỉ email <span className="text-red-500">*</span>
                </label>
                <input id="reg-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className={inputCls} />
              </div>
              <div>
                <label htmlFor="reg-pass" className={labelCls}>
                  Mật khẩu <span className="text-red-500">*</span>
                </label>
                <input id="reg-pass" type="password" required value={regPassword} onChange={(e) => setRegPassword(e.target.value)} className={inputCls} />
              </div>
              <p className="text-sm text-neutral-500 leading-relaxed">
                Dữ liệu cá nhân của bạn sẽ được dùng để hỗ trợ trải nghiệm mua sắm,
                quản lý tài khoản và cho các mục đích trong chính sách bảo mật của MONA.
              </p>
              <button type="submit" className="w-full bg-[#171a21] text-white py-6 text-sm tracking-[0.2em] hover:bg-black transition">
                ĐĂNG KÝ
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
