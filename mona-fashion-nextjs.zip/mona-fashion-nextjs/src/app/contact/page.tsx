"use client";
import { useState } from "react";

export default function ContactPage() {
  const [sent, setSent] = useState(false);

  return (
    <div className="bg-white">
      {/* ===== Hero: đèn treo + chữ Liên hệ (đúng ảnh mẫu) ===== */}
      <section className="relative h-[380px] md:h-[520px] bg-[#e4e9ec] overflow-hidden flex items-center justify-center">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/site/contact-hero.jpg"
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
        />
        <h1 className="relative font-heading font-thin text-6xl md:text-8xl tracking-wide text-[#20242e]">
          Liên hệ
        </h1>
      </section>

      {/* ===== Giới thiệu ===== */}
      <section className="container-x pt-14 pb-6">
        <p className="max-w-3xl mx-auto text-center text-neutral-500 leading-relaxed">
          Công ty thiết kế website và lập trình phần mềm / web, app · Văn phòng
          bắt đầu đi vào hoạt động và luôn sẵn sàng để tiếp nhận, tư vấn và hỗ
          trợ khách hàng
        </p>
      </section>

      {/* ===== Địa chỉ / Điện thoại / Email ===== */}
      <section className="container-x pb-14">
        <div className="max-w-3xl mx-auto space-y-8">
          <div className="flex items-start gap-6">
            <span className="text-2xl w-8 text-center" aria-hidden>⌂</span>
            <span className="w-32 shrink-0 text-[13px] font-medium tracking-wide text-neutral-600 pt-1">
              ĐỊA CHỈ
            </span>
            <span className="text-[15px] text-neutral-900">
              1073/23 Đ. Cách Mạng Tháng 8, P.7, Tân Bình, Thành phố Hồ Chí Minh 72100
            </span>
          </div>
          <div className="flex items-start gap-6">
            <span className="text-2xl w-8 text-center" aria-hidden>☎</span>
            <span className="w-32 shrink-0 text-[13px] font-medium tracking-wide text-neutral-600 pt-1">
              SỐ ĐIỆN<br />THOẠI
            </span>
            <a href="tel:0313728397" className="text-[15px] text-neutral-900 pt-1 hover:underline">
              0313 728 397
            </a>
          </div>
          <div className="flex items-start gap-6">
            <span className="text-2xl w-8 text-center" aria-hidden>✉</span>
            <span className="w-32 shrink-0 text-[13px] font-medium tracking-wide text-neutral-600 pt-1">
              EMAIL
            </span>
            <a href="mailto:info@themona.global" className="text-[15px] text-neutral-900 pt-1 hover:underline">
              info@themona.global
            </a>
          </div>
        </div>
      </section>

      {/* ===== Bản đồ + Form liên hệ ===== */}
      <section className="grid md:grid-cols-2">
        <div className="min-h-[420px] bg-neutral-200">
          <iframe
            title="Bản đồ MONA - 1073/23 Cách Mạng Tháng 8, Tân Bình, TP.HCM"
            src="https://www.google.com/maps?q=1073%2F23%20C%C3%A1ch%20M%E1%BA%A1ng%20Th%C3%A1ng%208%2C%20Ph%C6%B0%E1%BB%9Dng%207%2C%20T%C3%A2n%20B%C3%ACnh%2C%20TP.HCM&output=embed"
            className="w-full h-full min-h-[420px] border-0"
            loading="lazy"
          />
        </div>

        <div className="relative bg-[#f5f6f7] px-8 py-12 md:px-16">
          <h2 className="text-3xl font-light text-neutral-900">Thông tin liên hệ</h2>

          {sent ? (
            <div className="mt-10 bg-white border border-emerald-200 p-6">
              <p className="font-medium text-emerald-700">Đã gửi liên hệ thành công ✓</p>
              <p className="text-sm text-neutral-500 mt-2">
                Cảm ơn bạn đã liên hệ MONA Fashion. Chúng tôi sẽ phản hồi qua email trong thời gian sớm nhất.
              </p>
              <button onClick={() => setSent(false)} className="text-sm underline mt-4">
                Gửi thêm một liên hệ khác
              </button>
            </div>
          ) : (
            <form
              className="mt-8 space-y-7"
              onSubmit={(e) => {
                e.preventDefault();
                setSent(true);
              }}
            >
              <div>
                <label htmlFor="ct-name" className="sr-only">Họ và Tên</label>
                <input id="ct-name" required placeholder="Họ và Tên"
                  className="w-full bg-transparent border-b border-neutral-300 focus:border-black outline-none py-3 placeholder:text-neutral-500" />
              </div>
              <div>
                <label htmlFor="ct-email" className="sr-only">Email</label>
                <input id="ct-email" type="email" required placeholder="Email"
                  className="w-full bg-transparent border-b border-neutral-300 focus:border-black outline-none py-3 placeholder:text-neutral-500" />
              </div>
              <div>
                <label htmlFor="ct-subject" className="sr-only">Chủ đề</label>
                <input id="ct-subject" placeholder="Chủ đề"
                  className="w-full bg-transparent border-b border-neutral-300 focus:border-black outline-none py-3 placeholder:text-neutral-500" />
              </div>
              <div>
                <label htmlFor="ct-message" className="sr-only">Nội dung</label>
                <textarea id="ct-message" required placeholder="Nội dung" rows={4}
                  className="w-full bg-transparent border-b border-neutral-300 focus:border-black outline-none py-3 placeholder:text-neutral-500 resize-y" />
              </div>
              <button type="submit"
                className="w-full bg-[#171a21] text-white py-5 text-sm tracking-[0.25em] hover:bg-black transition">
                GỬI
              </button>
            </form>
          )}

          <button
            aria-label="Về đầu trang"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="absolute right-5 top-1/2 w-11 h-11 rounded-full border border-neutral-400 bg-white/70 grid place-items-center hover:bg-white"
          >
            ↑
          </button>
        </div>
      </section>
    </div>
  );
}
