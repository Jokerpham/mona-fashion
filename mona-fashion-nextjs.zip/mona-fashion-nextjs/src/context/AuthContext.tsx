"use client";
import { createContext, useContext, useEffect, useState, ReactNode } from "react";

export type User = { name: string; email: string };
type StoredUser = User & { password: string };

type AuthCtx = {
  user: User | null;
  register: (name: string, email: string, password: string) => { ok: boolean; error?: string };
  login: (identifier: string, password: string, remember: boolean) => { ok: boolean; error?: string };
  logout: () => void;
};

const Ctx = createContext<AuthCtx | null>(null);
const USERS_KEY = "mona-users";
const SESSION_KEY = "mona-session";

function loadUsers(): StoredUser[] {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
  } catch {
    return [];
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    try {
      const s = localStorage.getItem(SESSION_KEY) || sessionStorage.getItem(SESSION_KEY);
      if (s) setUser(JSON.parse(s));
    } catch {}
  }, []);

  const startSession = (u: User, remember: boolean) => {
    const storage = remember ? localStorage : sessionStorage;
    storage.setItem(SESSION_KEY, JSON.stringify(u));
    setUser(u);
  };

  const register: AuthCtx["register"] = (name, email, password) => {
    const users = loadUsers();
    if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: "Email này đã được đăng ký. Vui lòng đăng nhập." };
    }
    const newUser: StoredUser = { name, email, password };
    localStorage.setItem(USERS_KEY, JSON.stringify([...users, newUser]));
    startSession({ name, email }, true);
    return { ok: true };
  };

  const login: AuthCtx["login"] = (identifier, password, remember) => {
    const users = loadUsers();
    const found = users.find(
      (u) =>
        (u.email.toLowerCase() === identifier.toLowerCase() ||
          u.name.toLowerCase() === identifier.toLowerCase()) &&
        u.password === password
    );
    if (!found) {
      return {
        ok: false,
        error: "Sai tên tài khoản/email hoặc mật khẩu. Nếu chưa có tài khoản, hãy chọn tab Đăng ký.",
      };
    }
    startSession({ name: found.name, email: found.email }, remember);
    return { ok: true };
  };

  const logout = () => {
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
    setUser(null);
  };

  return <Ctx.Provider value={{ user, register, login, logout }}>{children}</Ctx.Provider>;
}

export const useAuth = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be used within AuthProvider");
  return c;
};
